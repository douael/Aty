<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_2110f74617fdabfa778c48806fdcc9a8'] = 'JMS AJAX Search';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_d8ddceb83a1e4a10d11d2c0dbfd2aaaf'] = 'JMS AJAX Search';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_8f31eb2413dea86c661532d4cf973d2f'] = 'An invalid number of products has been specified.';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_6af91e35dff67a43ace060d1d57d5d1a'] = 'Your settings have been updated.';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_d44168e17d91bac89aab3f38d8a4da8e'] = 'Number of products to be displayed';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_d80a06fda058b02ca2ab481cb6c6526b'] = 'Show Description';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_31dcfe3fddb9b5ba296be87d87b1a0a3'] = 'Description character limit';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_3b916fc8872fea5743ec9d4b4fee2de3'] = 'Show Price';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_67d32efccb13e15ce36e763c7ae970f5'] = 'Show Image';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_05c1ba76550139b96b26563d0dc14180'] = 'Search Now';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_18b4ca0be265ba968a6f1d3b41e85833'] = 'View my customer Compare';
$_MODULE['<{jmsajaxsearch}prestashop>jmsajaxsearch_4656814d604eeebfd8ba4e61b14b3c78'] = 'View my Wishlist';
